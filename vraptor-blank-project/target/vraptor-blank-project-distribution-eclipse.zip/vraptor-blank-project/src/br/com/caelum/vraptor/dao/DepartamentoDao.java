package br.com.caelum.vraptor.dao;

import java.util.List;

import javax.persistence.EntityManager;

import br.com.caelum.vraptor.model.Departamento;

public class DepartamentoDao {
	
	private final EntityManager em;
	
	public DepartamentoDao(EntityManager em) {
		this.em = em;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Departamento> listarDepartamentos(){
        return em.createQuery("select d from Departamento d").getResultList();
	}
}
